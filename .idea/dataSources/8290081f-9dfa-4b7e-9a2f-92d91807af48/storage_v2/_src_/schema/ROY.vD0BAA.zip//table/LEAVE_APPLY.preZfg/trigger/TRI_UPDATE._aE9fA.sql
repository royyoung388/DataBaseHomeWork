create trigger TRI_UPDATE
  after update of STATE
  on LEAVE_APPLY
  for each row
  BEGIN
    INSERT INTO MESSAGE
    VALUES (6, '同学你好，你的申请单' || :NEW.STATE, :NEW.APPLYNUM, :NEW.STUDENTNUM, TO_DATE(SYSDATE, 'YY/MM/DD HH24:MI:SS'));
  END;
/

