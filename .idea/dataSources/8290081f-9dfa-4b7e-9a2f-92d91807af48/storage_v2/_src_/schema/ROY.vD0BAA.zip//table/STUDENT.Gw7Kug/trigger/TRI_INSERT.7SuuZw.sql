create trigger TRI_INSERT
  before insert
  on STUDENT
  for each row
  when (NEW.CLASS = 99)
  BEGIN
    SELECT 1
    INTO :NEW.CLASS
    FROM dual;
  end;
/

