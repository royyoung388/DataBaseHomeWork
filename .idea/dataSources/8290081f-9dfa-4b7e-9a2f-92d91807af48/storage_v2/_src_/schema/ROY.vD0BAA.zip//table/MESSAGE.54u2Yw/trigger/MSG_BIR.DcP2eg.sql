create trigger MSG_BIR
  before insert
  on MESSAGE
  for each row
  BEGIN
    SELECT MSG_SEQ.NEXTVAL
    INTO :new.MESSAGENUM
    FROM dual;
  END;
/

