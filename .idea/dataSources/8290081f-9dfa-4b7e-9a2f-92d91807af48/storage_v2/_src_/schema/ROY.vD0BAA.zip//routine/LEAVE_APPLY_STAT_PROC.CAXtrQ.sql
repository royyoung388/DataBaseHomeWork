create PROCEDURE leave_apply_stat_proc
AS BEGIN
  INSERT INTO LEAVE_APPLY_STAT SELECT
                                 STUDENTNUM,
                                 COUNT(STUDENTNUM)
                               FROM LEAVE_APPLY
                               GROUP BY STUDENTNUM;
END;
/

